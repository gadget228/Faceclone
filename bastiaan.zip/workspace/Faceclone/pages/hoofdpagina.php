<?php
include '../DB.php';
session_start();
db_connect();

$email = $_SESSION['username'];
mysqli_select_db($db, $database);
$log_Query = "SELECT Naam,Email,Password FROM Users WHERE Email = '$email'";
$log_result = mysqli_query($db, $log_Query) OR die("ERRO:".mysqli_error($db));

$row_log = mysqli_fetch_array($log_result);

$_SESSION['Fullname'] = $row_log['Naam'];
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<title>Hoofdpagina</title>

<!-- Favicon -->
<link href="img/logo.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />
</head>
<body style="background-color: #efefef">
 <nav class="navbar navbar-light navbar-toggleable-md" style="background-color: #012c9c">
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon" />
            </button>
            <a class="navbar-brand">
				<img src="img/logo1.png" width="150" height="36" class="d-inline-block align-top" alt="logo">
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                 							
				</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="nav-item"><a class="nav-link" href="hoofdpagina.php" style="color: #FFFFFF;">Home</a></li>
				<li class="nav-item"><a class="nav-link" href="profile.php" style="color: #FFFFFF;">
				    <?php
				    echo $_SESSION['Fullname'];
				    ?>
				</a></li>
				<li class="nav-item"><a class="nav-link" href="" style="color: #FFFFFF;">Uitloggen</a></li>
			</ul>
            </div>
        </nav>
        <div class="container">
        <div class="row">
        	<div class="col-md-2">
        	<div class="card">
        	<div class="card-block">
        		Krijg hier meldingen van activiteiten
        		</div>
        		</div>
        	</div>
        	<div class="col-md-8">
        		<div class="card">
 				 <div class="card-block">
  				     <form action="../create-post.php" method="POST">
  				         <input type="textarea" class="form-control" name="Post"/>
  				         <input type="submit" class="btn btn-primary" name="Posten">
  				     </form>
  				 </div>
				</div>
        	</div>
        	<div class="col-md-2">
        	<div class="card">
        	<div class="card-block">
        		Voeg vrienden hier toe
        		</div>
        		</div>
        	</div>
        </div>
        <?php
        //WHERE Dates IN (SELECT max(Dates) FROM table)
        $SQL = "SELECT * FROM Posts order by Date";
        mysqli_select_db($db, $database);
        $result = mysqli_query($db, $SQL);
        if (!$result)
        {
            echo "error:".mysqli_error($db);
        }
        while($row = mysqli_fetch_array($result))
        {
        echo '
         <div class="row">
        	<div class="col-md-2">
        	</div>
        	<div class="col-md-8">
        		<div class="card">
 				 <div class="card-block">
  				  '.$row['Postinfo'].'<br>
  				  '.$row['Date'].'
  				 </div>
				</div>
        	</div>
        	<div class="col-md-2">
        	</div>
        </div>
        ';
        }
        ?>
        </div>
</body>
</html>