<?php
include 'DB.php';
session_start();
db_connect();
	
	if (!empty($_POST['reg'])){
		
		$fullname	= mysqli_escape_string($db, $_POST['fullname']);
		$email		= mysqli_escape_string($db, $_POST['email']);
		$password	= mysqli_escape_string($db, $_POST['Password']);
		$gender		= mysqli_escape_string($db, $_POST['sex']);
		$birthdat	= mysqli_escape_string($db, $_POST['GebDat']);
		
		mysqli_select_db($db, $database);
		
		
	    $reg_Query = "INSERT INTO Users(Naam, Email, Password, Birthdat, Sex) VALUES('$fullname', '$email','$password','$birthdat','$gender')";
		$reg_result = mysqli_query($db, $reg_Query) OR die("ERRO:".mysqli_error($db));
		
		if ($reg_result)
			{
			echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
					<a href='' class='close' data-dismiss='alert' aria-label='close'>X</a>
							U bent succesvol geregistreerd!
						</div>";	
			}
	}
	
	if (!empty($_POST['log'])){
		
		$emaillog		= mysqli_escape_string($db, $_POST['emaillog']);
		$passwordlog	= mysqli_escape_string($db, $_POST['passwordlog']);
		
		mysqli_select_db($db, $database);
		
		$log_Query = "SELECT Email,Password FROM Users WHERE Email = '$emaillog' AND Password = '$passwordlog'";
		$log_result = mysqli_query($db, $log_Query) OR die("ERRO:".mysqli_error($db));
		mysqli_fetch_assoc($log_result);
		
		if ($log_result)
		{
		/*	echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
					<a href='' class='close' data-dismiss='alert' aria-label='close'>X</a>
							U bent succesvol ingelogged!
						</div>"; */
						$_SESSION['username'] = $emaillog;
						header("Location: /Faceclone/pages/hoofdpagina.php");
		}
	}
?>

<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<title>Inlog pagina</title>

<!-- Favicon -->
<link href="img/logo.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />
</head>
<body style="background-color: #efefef">
 <!-- Navbar -->
        <nav class="navbar navbar-light navbar-toggleable-md" style="background-color: #012c9c">
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon" />
            </button>
            <a class="navbar-brand">
				<img src="img/logo1.png" width="150" height="36" class="d-inline-block align-top" alt="logo">
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                 							
				</ul>
				<form class="form-inline" method="post" action="">
  <label class="sr-only" for="inlineFormInput">E-mail</label>
  <input type="text" class="form-control mb-2 mr-sm-2 mb-sm-0" id="inlineFormInput" placeholder="E-mail" name="emaillog">

  <label class="sr-only" for="inlineFormInputGroup">Wachtwoord</label>
  <div class="input-group mb-2 mr-sm-2 mb-sm-0">
    <input type="password" class="form-control" id="inlineFormInputGroup" placeholder="Wachtwoord" name="passwordlog">
  </div>
				
				<span class="nav-link"> </span>
				
					<input type="submit" name="log" class="btn btn-outline-secondary my-2 my-sm-0" value="Aanmelden" style="color: white;"/>
				
				</form>
            </div>
        </nav>
        
        <div class="container">
        <div class="row">
        	<div class="col-md-6">
        	<br>
        	<br>
        	<br>
        		<h3>Met Facebook ben je verbonden en deel je alles met iedereen in je leven.</h3>
        		<img src="https://www.facebook.com/rsrc.php/v3/yc/r/GwFs3_KxNjS.png">
        	</div>
        	<div class="col-md-6">
        	<br>
        	<br>
        		<h1>Registreren</h1>
        		<h4>Het is gratis (en dat blijft het ook).</h4>
        		<form method="post">
        			<div class="form-group">
        				<input type="text" class="form-control" name="fullname" placeholder="Volledige naam"/>
        			</div>
        			<div class="form-group">
        				<input type="text" class="form-control" name="email" placeholder="E-mail"/>
        			</div>
        			<div class="form-group">
        				<input type="password" class="form-control" name="Password" placeholder="Wachtwoord"/>
        			</div>
        			<div class="form-group">
        				<input type="date" class="form-control" name="GebDat" placeholder="Geboorte Datum"/>
        			</div>
        		<!--	<div class="form-group">
        				<div class="g-recaptcha" data-sitekey="6Lc1aEQUAAAAAGEQSmaNeUn7LpwLbphggvn-LnTn"></div>
        			</div> -->
        			<div class="form-group">
        				<div class="custom-controls-stacked">
  						<label class="custom-control custom-radio">
 					   <input id="radioStacked1" name="sex" type="radio" class="custom-control-input" value="Man">
  					  <span class="custom-control-indicator"></span>
  					  <span class="custom-control-description">Man</span>
 					 </label>
 					 <label class="custom-control custom-radio">
   					 <input id="radioStacked2" name="sex" type="radio" class="custom-control-input" value="Vrouw">
    				<span class="custom-control-indicator"></span>
    				<span class="custom-control-description">Vrouw</span>
  					</label>
					</div>
        			</div>
        			
        			<div class="form-group">
        				<p style="color: #b7b7b7; font-size: 12px;">
        					Door op Account maken te klikken, ga je akkoord met onze Algemene voorwaarden en geef je aan dat je ons Gegevensbeleid, inclusief het beleid inzake cookiegebruik, hebt gelezen. Je kunt sms-meldingen van Facebook ontvangen en kunt je hiervoor op elk gewenst moment afmelden.
        				</p>
        			</div>
        			<input type="submit" class="btn btn-primary" value="Account maken" name="reg"/>
        		</form>
        	</div>
        	</div>
        </div>
</body>
</html>