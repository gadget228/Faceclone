<?php
include '/Faceclone/DB.php';
session_start();

function create_post();
{
$USERID = $_SESSION['Fullname'];
$post = $_POST['Post'];
$date = date("Y-m-d h:i:sa");
$SQL = "INSERT INTO Users (UserID, Postinfo, Date)
VALUES ($USERID, $post, $date)";
$result = mysqli_query($db, $SQL) OR die("ERRO:".mysqli_error($db));

if (!$result)
{
    echo"ERROR: ".mysqli_error($db);
}
}

if ($_POST['Posten'])
{
    create_post();
    echo 'I did it';
}
else{
    echo 'Kanker';
}
?>